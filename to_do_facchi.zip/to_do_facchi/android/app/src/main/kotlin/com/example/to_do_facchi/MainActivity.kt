package com.example.to_do_facchi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
