import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class HomePage extends StatefulWidget {
  static String routeName = "/home";

  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late CalendarController _controller;

  @override
  void initState() {
    super.initState();
    _controller = CalendarController();
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              /*SizedBox(height: 30),
              TableCalendar(
                startingDayOfWeek: StartingDayOfWeek.monday,
                calendarStyle: CalendarStyle(
                  weekdayStyle: TextStyle(
                      color: Color(0xff30384c), fontWeight: FontWeight.normal),
                  weekendStyle: TextStyle(
                      color: Color(0xff30384c), fontWeight: FontWeight.normal),
                  selectedColor: Color(0xff30374b),
                  todayColor: Color(0xff30374b),
                ),
                daysOfWeekStyle: DaysOfWeekStyle(
                  weekdayStyle: TextStyle(
                      //color: Color(0xff30384c),
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                  weekendStyle: TextStyle(
                      color: Color(0xff30384c),
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
                headerStyle: HeaderStyle(
                  formatButtonVisible: false,
                  titleTextStyle: TextStyle(
                      color: Color(0xff30384c),
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                  leftChevronIcon: Icon(
                    Icons.chevron_left,
                    color: Color(0xff30384c),
                  ),
                  rightChevronIcon: Icon(
                    Icons.chevron_right,
                    color: Color(0xff30384c),
                  ),
                ),
                calendarController: _controller,
              ),*/
              //SizedBox(height: 20),
              Container(
                //padding: EdgeInsets.only(left: 30),
                width: MediaQuery.of(context).size.width,
                //size relative to screen size
                height: MediaQuery.of(context).size.height, //*0.55
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(50),
                        topRight: Radius.circular(50)),
                    color: Color(0xff30384c)),
                child: Stack(
                  children: <Widget>[
                    Column(
                      //crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        /*Padding(
                          padding: EdgeInsets.only(top: 50),
                          child: Text(
                            "Today",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),*/
                        Container(
                          padding: EdgeInsets.only(top: 20),
                          child: Row(
                            children: <Widget>[
                              /*Icon(
                                CupertinoIcons.check_mark_circled_solid,
                                color: Color(0xff00cf8d),
                                size: 30,
                              ),*/
                              Container(
                                //padding: EdgeInsets.only(left: 10, right: 10),
                                width: MediaQuery.of(context).size.width ,
                                child: Column(
                                  children: <Widget>[
                                    /*Expanded(
                                        child: ListView(),
                                    ),*/
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 18),
                                      decoration: BoxDecoration(
                                        color: Colors.black38,
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(20),
                                          topRight: Radius.circular(20),
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          Expanded(child: TextField(
                                              decoration: InputDecoration(
                                                filled: true,
                                                fillColor: Color(0xff30384c),
                                                hintText: "Type a new Task",
                                              ),
                                            ),
                                          ),
                                          FlatButton.icon(
                                            icon: Icon(Icons.add, color: Colors.white),
                                            label: Text("Add Task"),
                                            color: Colors.purple,
                                            shape: StadiumBorder(),
                                            textColor: Colors.white,
                                            onPressed: (){},

                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
